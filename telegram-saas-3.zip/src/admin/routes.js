const express = require('express');
const router = express.Router();
const db = require('../db');
const logger = require('../utils/logger');

// Admin auth middleware
function adminAuth(req, res, next) {
  const apiKey = req.headers['x-admin-key'];
  if (apiKey !== process.env.ADMIN_API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
}

router.use(adminAuth);

// GET /admin/stats
router.get('/stats', async (req, res) => {
  try {
    const [users] = await db('users').count('id as count');
    const [bots] = await db('bots').count('id as count');
    const [active] = await db('bots').where({ status: 'active' }).count('id as count');
    const [revenue] = await db('transactions').where({ status: 'success' }).sum('amount as total');

    res.json({
      users: parseInt(users.count),
      bots: parseInt(bots.count),
      active_bots: parseInt(active.count),
      total_revenue: parseInt(revenue.total || 0),
    });
  } catch (err) {
    logger.error('Admin stats error:', err);
    res.status(500).json({ error: 'Internal error' });
  }
});

// GET /admin/bots
router.get('/bots', async (req, res) => {
  try {
    const bots = await db('bots')
      .join('users', 'bots.owner_id', 'users.id')
      .select(
        'bots.id', 'bots.bot_username', 'bots.status',
        'bots.subscription_end', 'bots.created_at',
        'users.telegram_id as owner_telegram_id'
      )
      .orderBy('bots.created_at', 'desc');
    res.json(bots);
  } catch (err) {
    res.status(500).json({ error: 'Internal error' });
  }
});

// GET /admin/transactions
router.get('/transactions', async (req, res) => {
  try {
    const { provider, status, limit = 50 } = req.query;
    let query = db('transactions').orderBy('created_at', 'desc').limit(parseInt(limit));

    if (provider) query = query.where({ provider });
    if (status) query = query.where({ status });

    const txs = await query;
    res.json(txs);
  } catch (err) {
    res.status(500).json({ error: 'Internal error' });
  }
});

// GET /admin/users
router.get('/users', async (req, res) => {
  try {
    const users = await db('users')
      .select('users.*', db.raw('COUNT(bots.id) as bot_count'))
      .leftJoin('bots', 'users.id', 'bots.owner_id')
      .groupBy('users.id')
      .orderBy('users.created_at', 'desc');
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: 'Internal error' });
  }
});

module.exports = router;
