require('dotenv').config();

const express = require('express');
const TelegramBot = require('node-telegram-bot-api');

const logger = require('./utils/logger');
const db = require('./db');
require('./config/redis'); // Redis ulanish

const { loadAllBots, startChildBot } = require('./bots/botManager');
const { handleMainBotMessage, handleMainBotCallback, handleActivateCommand } = require('./bots/mainBotHandler');
const { webhookAuth } = require('./middlewares/webhookAuth');
const { clickPrepare, clickComplete } = require('./payments/click');
const { paymeHandler } = require('./payments/payme');
const adminRoutes = require('./admin/routes');
const { startCronJobs } = require('./cron');

const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// ─── Middleware ───────────────────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ─── Static fayllar (qo'llanma va boshqalar) ──────────────────
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// ─── Qo'llanma — ochiq (public), admin username inject ───────
app.get('/guide', (req, res) => {
  const fs = require('fs');
  const filePath = path.join(__dirname, '..', 'public', 'qollanma.html');
  let html = fs.readFileSync(filePath, 'utf8');
  // Admin username ni HTML ga inject qilamiz
  const adminUsername = process.env.PAYMENT_ADMIN_USERNAME || 'jaconjs';
  html = html.replace(/ADMIN_USERNAME_PLACEHOLDER/g, adminUsername);
  res.send(html);
});

// ─── Health check ─────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ─── Payment Routes ───────────────────────────────────────────
app.post('/api/click/prepare', clickPrepare);
app.post('/api/click/complete', clickComplete);
app.post('/api/payme', paymeHandler);

// ─── Admin REST API ───────────────────────────────────────────
app.use('/admin', adminRoutes);

// ─── OTA-BOT (Main Bot) ───────────────────────────────────────
const mainBot = new TelegramBot(process.env.MAIN_BOT_TOKEN);

// Main bot webhook
app.post('/webhook/main', webhookAuth, (req, res) => {
  mainBot.processUpdate(req.body);
  res.sendStatus(200);
});

mainBot.on('message', (msg) => {
  if (msg.text && msg.text.startsWith('/activate')) {
    return handleActivateCommand(mainBot, msg, app);
  }
  return handleMainBotMessage(mainBot, msg, app);
});
mainBot.on('callback_query', (query) => handleMainBotCallback(mainBot, query, app));

mainBot.on('polling_error', (err) => logger.error('Main bot error:', err.message));

// ─── Kino indexer (manba kanaldan post kelganda) ──────────────
// Bot admin sifatida qo'shilgan manba kanaldan yangi postlarni
// avtomatik indexlash uchun channel_post handlerni ishlatamiz
mainBot.on('channel_post', async (msg) => {
  try {
    if (!msg.caption && !msg.text) return;

    const text = msg.caption || msg.text || '';
    // "#KN001" yoki "KN001" formatidagi kodni topish
    const match = text.match(/#?([A-Z0-9]{3,15})/i);
    if (!match) return;

    const code = match[1].toUpperCase();
    const channelId = String(msg.chat.id);

    await db('movies')
      .insert({
        code,
        channel_id: channelId,
        message_id: msg.message_id,
        title: text.split('\n')[0].replace(/^#?\S+\s*/, '').trim() || null,
      })
      .onConflict(['code', 'channel_id'])
      .merge(['message_id', 'title', 'updated_at']);

    logger.info(`🎬 Movie indexed: ${code} (channel: ${channelId}, msg: ${msg.message_id})`);
  } catch (err) {
    logger.error('Movie indexing error:', err.message);
  }
});

// ─── Server ishga tushirish ───────────────────────────────────
async function bootstrap() {
  try {
    // DB migratsiya tekshirish
    await db.raw('SELECT 1');
    logger.info('✅ Database ready');

    // Main bot webhook o'rnatish
    const mainWebhookUrl = `${process.env.BASE_URL}/webhook/main`;
    await mainBot.setWebHook(mainWebhookUrl, {
      secret_token: process.env.WEBHOOK_SECRET,
    });
    logger.info(`✅ Main bot webhook: ${mainWebhookUrl}`);

    // Barcha active child botlarni yuklash
    await loadAllBots(app);

    // Cron joblarni ishga tushirish
    startCronJobs();

    // Serverni ishga tushirish
    app.listen(PORT, () => {
      logger.info(`🚀 Server running on port ${PORT}`);
      logger.info(`📡 Base URL: ${process.env.BASE_URL}`);
    });
  } catch (err) {
    logger.error('❌ Bootstrap failed:', err);
    process.exit(1);
  }
}

// ─── Graceful shutdown ────────────────────────────────────────
process.on('SIGTERM', async () => {
  logger.info('SIGTERM received, shutting down...');
  await db.destroy();
  process.exit(0);
});

process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled rejection:', reason);
});

bootstrap();
