const cron = require('node-cron');
const logger = require('../utils/logger');
const { deactivateExpiredBots, notifyExpiringBots } = require('../utils/subscription');

function startCronJobs() {
  // Har soatda expired botlarni tekshirish
  cron.schedule('0 * * * *', async () => {
    logger.info('⏰ Cron: Checking expired subscriptions...');
    const count = await deactivateExpiredBots();
    if (count > 0) logger.info(`🔴 Deactivated ${count} expired bots`);
  });

  // Har kuni soat 10:00 da ogohlantirish
  cron.schedule('0 10 * * *', async () => {
    logger.info('⏰ Cron: Sending expiry notifications...');
    await notifyExpiringBots();
  });

  logger.info('✅ Cron jobs started');
}

module.exports = { startCronJobs };
