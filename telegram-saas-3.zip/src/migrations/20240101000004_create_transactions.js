exports.up = function (knex) {
  return knex.schema.createTable('transactions', (table) => {
    table.increments('id').primary();
    table.enu('provider', ['click', 'payme']).notNullable();
    table.string('payment_id').nullable();       // Click trans ID / Payme transaction ID
    table.string('provider_trans_id').nullable(); // provider internal ID
    table.integer('bot_id').unsigned().references('id').inTable('bots').onDelete('SET NULL');
    table.bigInteger('amount').notNullable();     // tiyin/sum
    table.enu('status', ['pending', 'success', 'failed', 'cancelled']).defaultTo('pending');
    table.integer('duration_days').defaultTo(30);
    table.jsonb('raw_data').nullable();           // provider raw response
    table.timestamps(true, true);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('transactions');
};
