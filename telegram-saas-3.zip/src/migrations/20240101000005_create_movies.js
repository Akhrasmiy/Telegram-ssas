exports.up = function (knex) {
  return knex.schema.createTable('movies', (table) => {
    table.increments('id').primary();
    table.string('code').notNullable();          // kino kodi (masalan: "KN001")
    table.string('channel_id').notNullable();    // manba kanal ID
    table.bigInteger('message_id').notNullable(); // Telegram message ID
    table.string('title').nullable();
    table.timestamps(true, true);

    table.unique(['code', 'channel_id']);
    table.index(['code']);
    table.index(['channel_id']);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('movies');
};
