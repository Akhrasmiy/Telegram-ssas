exports.up = function (knex) {
  return knex.schema.createTable('channels', (table) => {
    table.increments('id').primary();
    table.integer('bot_id').unsigned().references('id').inTable('bots').onDelete('CASCADE');
    table.string('channel_id').notNullable(); // Telegram channel/group ID
    table.string('channel_name').nullable();
    table.string('invite_link').nullable();
    table.enu('type', ['mandatory', 'group', 'source']).defaultTo('mandatory');
    table.timestamps(true, true);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('channels');
};
