exports.up = function (knex) {
  return knex.schema.createTable('bots', (table) => {
    table.increments('id').primary();
    table.integer('owner_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
    table.text('token_encrypted').notNullable(); // encrypted token
    table.string('bot_username').nullable();
    table.string('bot_name').nullable();
    table.enu('status', ['active', 'inactive', 'suspended']).defaultTo('inactive');
    table.timestamp('subscription_end').nullable();
    table.bigInteger('source_channel_id').nullable(); // kino manba kanal
    table.timestamps(true, true);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('bots');
};
