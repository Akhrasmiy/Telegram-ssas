const crypto = require('crypto');
const db = require('../db');
const logger = require('../utils/logger');
const { activateSubscription } = require('../utils/subscription');

// Click sign tekshirish
function verifyClickSign(params, secretKey) {
  const {
    click_trans_id,
    service_id,
    click_paydoc_id,
    merchant_trans_id,
    amount,
    action,
    sign_time,
    sign_string,
  } = params;

  const signString = `${click_trans_id}${service_id}${secretKey}${merchant_trans_id}${amount}${action}${sign_time}`;
  const hash = crypto.createHash('md5').update(signString).digest('hex');
  return hash === sign_string;
}

// Error kodlar
const CLICK_ERRORS = {
  SUCCESS: { error: 0, error_note: 'Success' },
  SIGN_ERROR: { error: -1, error_note: 'SIGN CHECK FAILED!' },
  INCORRECT_AMOUNT: { error: -2, error_note: 'Incorrect parameter amount' },
  ACTION_NOT_FOUND: { error: -3, error_note: 'Action not found' },
  OBJECT_NOT_FOUND: { error: -5, error_note: 'User does not exist' },
  TRANSACTION_NOT_FOUND: { error: -6, error_note: 'Transaction does not exist' },
  TRANSACTION_CANCELLED: { error: -4, error_note: 'Transaction cancelled' },
  ALREADY_PAID: { error: -4, error_note: 'Already paid' },
};

// PREPARE
async function clickPrepare(req, res) {
  try {
    const params = req.body;
    logger.info('Click PREPARE:', params);

    // Sign tekshirish
    if (!verifyClickSign(params, process.env.CLICK_SECRET_KEY)) {
      return res.json({
        ...CLICK_ERRORS.SIGN_ERROR,
        click_trans_id: params.click_trans_id,
        merchant_trans_id: params.merchant_trans_id,
      });
    }

    // merchant_trans_id = "bot_123"
    const botId = parseInt(params.merchant_trans_id.replace('bot_', ''));
    const botRecord = await db('bots').where({ id: botId }).first();

    if (!botRecord) {
      return res.json({
        ...CLICK_ERRORS.OBJECT_NOT_FOUND,
        click_trans_id: params.click_trans_id,
        merchant_trans_id: params.merchant_trans_id,
      });
    }

    // Amount tekshirish
    const expectedAmount = parseInt(process.env.SUBSCRIPTION_PRICE_MONTHLY);
    if (Math.abs(parseFloat(params.amount) - expectedAmount) > 1) {
      return res.json({
        ...CLICK_ERRORS.INCORRECT_AMOUNT,
        click_trans_id: params.click_trans_id,
        merchant_trans_id: params.merchant_trans_id,
      });
    }

    // Transaction yaratish
    const existing = await db('transactions')
      .where({ payment_id: String(params.click_trans_id), provider: 'click' })
      .first();

    if (!existing) {
      await db('transactions').insert({
        provider: 'click',
        payment_id: String(params.click_trans_id),
        bot_id: botId,
        amount: params.amount,
        status: 'pending',
        raw_data: JSON.stringify(params),
      });
    }

    return res.json({
      ...CLICK_ERRORS.SUCCESS,
      click_trans_id: params.click_trans_id,
      merchant_trans_id: params.merchant_trans_id,
      merchant_prepare_id: existing?.id || 0,
    });
  } catch (err) {
    logger.error('Click PREPARE error:', err);
    return res.status(500).json({ error: -9, error_note: 'Internal server error' });
  }
}

// COMPLETE
async function clickComplete(req, res) {
  try {
    const params = req.body;
    logger.info('Click COMPLETE:', params);

    // Sign tekshirish
    if (!verifyClickSign(params, process.env.CLICK_SECRET_KEY)) {
      return res.json({
        ...CLICK_ERRORS.SIGN_ERROR,
        click_trans_id: params.click_trans_id,
        merchant_trans_id: params.merchant_trans_id,
      });
    }

    // Transaction topish
    const transaction = await db('transactions')
      .where({ payment_id: String(params.click_trans_id), provider: 'click' })
      .first();

    if (!transaction) {
      return res.json({
        ...CLICK_ERRORS.TRANSACTION_NOT_FOUND,
        click_trans_id: params.click_trans_id,
        merchant_trans_id: params.merchant_trans_id,
      });
    }

    if (transaction.status === 'success') {
      return res.json({
        ...CLICK_ERRORS.ALREADY_PAID,
        click_trans_id: params.click_trans_id,
        merchant_trans_id: params.merchant_trans_id,
      });
    }

    // Error bo'lsa
    if (parseInt(params.error) < 0) {
      await db('transactions').where({ id: transaction.id }).update({ status: 'failed' });
      return res.json({
        ...CLICK_ERRORS.TRANSACTION_CANCELLED,
        click_trans_id: params.click_trans_id,
        merchant_trans_id: params.merchant_trans_id,
      });
    }

    // To'lov muvaffaqiyatli - subscription faollashtirish
    await db('transactions').where({ id: transaction.id }).update({ status: 'success' });
    await activateSubscription(transaction.bot_id, transaction.id);

    logger.info(`✅ Click payment success for bot #${transaction.bot_id}`);

    return res.json({
      ...CLICK_ERRORS.SUCCESS,
      click_trans_id: params.click_trans_id,
      merchant_trans_id: params.merchant_trans_id,
      merchant_confirm_id: transaction.id,
    });
  } catch (err) {
    logger.error('Click COMPLETE error:', err);
    return res.status(500).json({ error: -9, error_note: 'Internal server error' });
  }
}

module.exports = { clickPrepare, clickComplete };
