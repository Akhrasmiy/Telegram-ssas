const db = require('../db');
const logger = require('../utils/logger');
const { activateSubscription } = require('../utils/subscription');

// Payme error kodlar
const ERRORS = {
  PARSE_ERROR: { code: -32700, message: { uz: 'Parse error', ru: 'Ошибка разбора', en: 'Parse error' } },
  METHOD_NOT_FOUND: { code: -32601, message: { uz: 'Metod topilmadi', ru: 'Метод не найден', en: 'Method not found' } },
  INVALID_PARAMS: { code: -31001, message: { uz: 'Noto\'g\'ri parametrlar', ru: 'Неверные параметры', en: 'Invalid params' } },
  INSUFFICIENT_PRIVILEGE: { code: -32504, message: { uz: 'Ruxsat yo\'q', ru: 'Нет доступа', en: 'Insufficient privilege' } },
  OBJECT_NOT_FOUND: { code: -31050, message: { uz: 'Buyurtma topilmadi', ru: 'Заказ не найден', en: 'Order not found' } },
  INVALID_AMOUNT: { code: -31001, message: { uz: 'Noto\'g\'ri summa', ru: 'Неверная сумма', en: 'Invalid amount' } },
  TRANSACTION_NOT_FOUND: { code: -31003, message: { uz: 'Tranzaksiya topilmadi', ru: 'Транзакция не найдена', en: 'Transaction not found' } },
  UNABLE_TO_PERFORM: { code: -31008, message: { uz: 'Amalga oshirib bo\'lmaydi', ru: 'Невозможно выполнить', en: 'Unable to perform' } },
};

// Auth tekshirish
function verifyPaymeAuth(req) {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Basic ')) return false;

  const base64 = auth.replace('Basic ', '');
  const decoded = Buffer.from(base64, 'base64').toString('utf8');
  const [, password] = decoded.split(':');

  return (
    password === process.env.PAYME_SECRET_KEY ||
    password === process.env.PAYME_TEST_SECRET_KEY
  );
}

function jsonRpcResponse(result, id) {
  return { jsonrpc: '2.0', result, id };
}

function jsonRpcError(error, id) {
  return { jsonrpc: '2.0', error, id };
}

// CheckPerformTransaction
async function checkPerformTransaction(params, id) {
  const { account, amount } = params;

  const botId = account?.bot_id;
  if (!botId) {
    return jsonRpcError({ ...ERRORS.OBJECT_NOT_FOUND }, id);
  }

  const bot = await db('bots').where({ id: parseInt(botId) }).first();
  if (!bot) {
    return jsonRpcError({ ...ERRORS.OBJECT_NOT_FOUND }, id);
  }

  const expectedAmount = parseInt(process.env.SUBSCRIPTION_PRICE_MONTHLY) * 100; // tiyin
  if (amount !== expectedAmount) {
    return jsonRpcError({ ...ERRORS.INVALID_AMOUNT }, id);
  }

  return jsonRpcResponse({ allow: true }, id);
}

// CreateTransaction
async function createTransaction(params, id) {
  const { id: paymeId, account, amount, time } = params;

  const botId = account?.bot_id;
  if (!botId) return jsonRpcError(ERRORS.OBJECT_NOT_FOUND, id);

  const bot = await db('bots').where({ id: parseInt(botId) }).first();
  if (!bot) return jsonRpcError(ERRORS.OBJECT_NOT_FOUND, id);

  // Mavjud transaction
  const existing = await db('transactions')
    .where({ payment_id: paymeId, provider: 'payme' })
    .first();

  if (existing) {
    if (existing.status === 'cancelled' || existing.status === 'failed') {
      return jsonRpcError(ERRORS.UNABLE_TO_PERFORM, id);
    }
    return jsonRpcResponse({
      create_time: new Date(existing.created_at).getTime(),
      transaction: String(existing.id),
      state: 1,
    }, id);
  }

  // Yangi transaction
  const [tx] = await db('transactions')
    .insert({
      provider: 'payme',
      payment_id: paymeId,
      bot_id: parseInt(botId),
      amount: amount / 100, // so'm ga
      status: 'pending',
      raw_data: JSON.stringify(params),
    })
    .returning('*');

  return jsonRpcResponse({
    create_time: new Date(tx.created_at).getTime(),
    transaction: String(tx.id),
    state: 1,
  }, id);
}

// PerformTransaction
async function performTransaction(params, id) {
  const { id: paymeId } = params;

  const tx = await db('transactions')
    .where({ payment_id: paymeId, provider: 'payme' })
    .first();

  if (!tx) return jsonRpcError(ERRORS.TRANSACTION_NOT_FOUND, id);

  if (tx.status === 'success') {
    return jsonRpcResponse({
      transaction: String(tx.id),
      perform_time: new Date(tx.updated_at).getTime(),
      state: 2,
    }, id);
  }

  if (tx.status === 'cancelled' || tx.status === 'failed') {
    return jsonRpcError(ERRORS.UNABLE_TO_PERFORM, id);
  }

  // To'lovni amalga oshirish
  await db('transactions').where({ id: tx.id }).update({ status: 'success' });
  await activateSubscription(tx.bot_id, tx.id);

  logger.info(`✅ Payme payment success for bot #${tx.bot_id}`);

  return jsonRpcResponse({
    transaction: String(tx.id),
    perform_time: Date.now(),
    state: 2,
  }, id);
}

// CancelTransaction
async function cancelTransaction(params, id) {
  const { id: paymeId } = params;

  const tx = await db('transactions')
    .where({ payment_id: paymeId, provider: 'payme' })
    .first();

  if (!tx) return jsonRpcError(ERRORS.TRANSACTION_NOT_FOUND, id);

  if (tx.status === 'success') {
    return jsonRpcError(ERRORS.UNABLE_TO_PERFORM, id);
  }

  await db('transactions').where({ id: tx.id }).update({ status: 'cancelled' });

  return jsonRpcResponse({
    transaction: String(tx.id),
    cancel_time: Date.now(),
    state: -1,
  }, id);
}

// CheckTransaction
async function checkTransaction(params, id) {
  const { id: paymeId } = params;

  const tx = await db('transactions')
    .where({ payment_id: paymeId, provider: 'payme' })
    .first();

  if (!tx) return jsonRpcError(ERRORS.TRANSACTION_NOT_FOUND, id);

  const stateMap = { pending: 1, success: 2, cancelled: -1, failed: -1 };

  return jsonRpcResponse({
    create_time: new Date(tx.created_at).getTime(),
    perform_time: tx.status === 'success' ? new Date(tx.updated_at).getTime() : 0,
    cancel_time: tx.status === 'cancelled' ? new Date(tx.updated_at).getTime() : 0,
    transaction: String(tx.id),
    state: stateMap[tx.status] || 1,
    reason: null,
  }, id);
}

// Asosiy Payme handler
async function paymeHandler(req, res) {
  try {
    // Auth tekshirish
    if (!verifyPaymeAuth(req)) {
      return res.json(jsonRpcError(ERRORS.INSUFFICIENT_PRIVILEGE, req.body?.id));
    }

    const { method, params, id } = req.body;
    logger.info(`Payme method: ${method}`, params);

    let result;
    switch (method) {
      case 'CheckPerformTransaction':
        result = await checkPerformTransaction(params, id);
        break;
      case 'CreateTransaction':
        result = await createTransaction(params, id);
        break;
      case 'PerformTransaction':
        result = await performTransaction(params, id);
        break;
      case 'CancelTransaction':
        result = await cancelTransaction(params, id);
        break;
      case 'CheckTransaction':
        result = await checkTransaction(params, id);
        break;
      default:
        result = jsonRpcError(ERRORS.METHOD_NOT_FOUND, id);
    }

    return res.json(result);
  } catch (err) {
    logger.error('Payme handler error:', err);
    return res.json(jsonRpcError(ERRORS.PARSE_ERROR, req.body?.id));
  }
}

module.exports = { paymeHandler };
