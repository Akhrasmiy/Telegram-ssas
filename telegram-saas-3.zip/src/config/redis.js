const { createClient } = require('redis');
const logger = require('../utils/logger');

const client = createClient({ url: process.env.REDIS_URL });

client.on('error', (err) => logger.error('Redis error:', err));
client.on('connect', () => logger.info('✅ Redis connected'));

client.connect();

// Cache helpers
const cache = {
  async get(key) {
    try {
      const val = await client.get(key);
      return val ? JSON.parse(val) : null;
    } catch { return null; }
  },

  async set(key, value, ttlSeconds = 300) {
    try {
      await client.setEx(key, ttlSeconds, JSON.stringify(value));
    } catch (err) {
      logger.error('Redis set error:', err);
    }
  },

  async del(key) {
    try {
      await client.del(key);
    } catch (err) {
      logger.error('Redis del error:', err);
    }
  },

  async exists(key) {
    try {
      return await client.exists(key);
    } catch { return false; }
  },
};

module.exports = { client, cache };
