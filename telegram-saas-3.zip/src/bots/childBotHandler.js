const db = require('../db');
const { cache } = require('../config/redis');
const logger = require('../utils/logger');

// Majburiy kanallarga a'zolikni tekshirish
async function checkMembership(bot, userId, channels) {
  const notMember = [];

  for (const ch of channels) {
    const cacheKey = `membership:${userId}:${ch.channel_id}`;
    const cached = await cache.get(cacheKey);

    if (cached === true) continue;

    try {
      const member = await bot.getChatMember(ch.channel_id, userId);
      const isOk = ['member', 'administrator', 'creator'].includes(member.status);

      if (isOk) {
        await cache.set(cacheKey, true, 300); // 5 daqiqa cache
      } else {
        notMember.push(ch);
      }
    } catch {
      notMember.push(ch);
    }
  }

  return notMember;
}

// Majburiy kanallar tugmalari
function buildChannelButtons(channels) {
  const buttons = channels.map((ch) => [
    {
      text: ch.channel_name || `📢 Kanal`,
      url: ch.invite_link || `https://t.me/${ch.channel_id.replace('@', '')}`,
    },
  ]);
  buttons.push([{ text: '✅ Tekshirish', callback_data: 'check_subscription' }]);
  return { inline_keyboard: buttons };
}

// /start handler
async function handleStart(bot, msg, botRecord) {
  const userId = msg.from.id;

  // Majburiy kanallarni olish
  const channels = await db('channels').where({
    bot_id: botRecord.id,
    type: 'mandatory',
  });

  if (channels.length === 0) {
    return bot.sendMessage(userId, '👋 Salom! Kino kodini yuboring.');
  }

  const notMember = await checkMembership(bot, userId, channels);

  if (notMember.length > 0) {
    return bot.sendMessage(
      userId,
      `👋 Salom! Botdan foydalanish uchun quyidagi kanallarga a'zo bo'ling:`,
      { reply_markup: buildChannelButtons(notMember) }
    );
  }

  return bot.sendMessage(userId, '✅ Kino kodini yuboring!');
}

// Tekshirish callback
async function handleCheckCallback(bot, query, botRecord) {
  const userId = query.from.id;
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;

  // Cache ni tozalash (yangi tekshirish uchun)
  const channels = await db('channels').where({
    bot_id: botRecord.id,
    type: 'mandatory',
  });

  // Cache tozalash
  for (const ch of channels) {
    await cache.del(`membership:${userId}:${ch.channel_id}`);
  }

  const notMember = await checkMembership(bot, userId, channels);

  if (notMember.length > 0) {
    await bot.answerCallbackQuery(query.id, { text: "Siz hali barcha kanallarga a'zo emassiz!" });
    return bot.editMessageText(
      `❌ Siz barcha kanallarga a'zo emassiz!\n\nQuyidagi kanallarga a'zo bo'ling:`,
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: buildChannelButtons(notMember),
      }
    );
  }

  await bot.answerCallbackQuery(query.id, { text: '✅ Tabriklaymiz!' });
  return bot.editMessageText('✅ Ajoyib! Endi kino kodini yuboring.', {
    chat_id: chatId,
    message_id: messageId,
  });
}

// Kino olish logikasi
async function handleMovieRequest(bot, msg, botRecord) {
  const userId = msg.from.id;
  const code = msg.text.trim();

  // Avval a'zolikni tekshir
  const channels = await db('channels').where({
    bot_id: botRecord.id,
    type: 'mandatory',
  });

  if (channels.length > 0) {
    const notMember = await checkMembership(bot, userId, channels);
    if (notMember.length > 0) {
      return bot.sendMessage(
        userId,
        `❌ Avval kanallarga a'zo bo'ling:`,
        { reply_markup: buildChannelButtons(notMember) }
      );
    }
  }

  // Manba kanaldan kino qidirish
  if (!botRecord.source_channel_id) {
    return bot.sendMessage(userId, '❌ Manba kanal sozlanmagan. Admin bilan bog\'laning.');
  }

  try {
    // Manba kanalda #CODE bilan qidirish
    // Telegram search orqali topamiz
    const searchResult = await searchMovieInChannel(bot, botRecord.source_channel_id, code);

    if (!searchResult) {
      return bot.sendMessage(userId, `❌ "${code}" kodli kino topilmadi.`);
    }

    // copyMessage - forward emas!
    await bot.copyMessage(userId, botRecord.source_channel_id, searchResult.message_id);

  } catch (err) {
    logger.error(`Movie search error for bot #${botRecord.id}:`, err.message);
    return bot.sendMessage(userId, '❌ Xatolik yuz berdi. Keyinroq urinib ko\'ring.');
  }
}

// Kino qidirish - manba kanaldan
async function searchMovieInChannel(bot, channelId, code) {
  try {
    // Telegram Bot API da forward history yo'q,
    // shuning uchun DB da kino indexini saqlaymiz
    const movie = await db('movies')
      .where({ code: code.toUpperCase() })
      .whereRaw('channel_id = ?', [String(channelId)])
      .first();

    return movie || null;
  } catch {
    return null;
  }
}

// Asosiy message handler
async function handleChildBotMessage(bot, msg, botRecord) {
  if (!msg.text) return;

  // Bot inactive bo'lsa
  if (botRecord.status !== 'active') {
    return bot.sendMessage(msg.chat.id, '⚠️ Bot hozirda ishlamayapti.');
  }

  const text = msg.text.trim();

  if (text === '/start') {
    return handleStart(bot, msg, botRecord);
  }

  // Boshqa barcha xabar = kino kodi
  return handleMovieRequest(bot, msg, botRecord);
}

// Callback query handler
async function handleChildBotCallback(bot, query, botRecord) {
  if (query.data === 'check_subscription') {
    return handleCheckCallback(bot, query, botRecord);
  }
  await bot.answerCallbackQuery(query.id);
}

module.exports = {
  handleChildBotMessage,
  handleChildBotCallback,
};
