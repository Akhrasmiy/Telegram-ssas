const TelegramBot = require('node-telegram-bot-api');
const db = require('../db');
const { encrypt, decrypt } = require('../utils/encryption');
const { startChildBot, stopChildBot } = require('./botManager');
const logger = require('../utils/logger');

// User states (bot yaratish jarayoni)
const userStates = new Map();

// Admin tekshirish
function isAdmin(userId) {
  const adminIds = (process.env.ADMIN_IDS || '').split(',').map((id) => parseInt(id.trim()));
  return adminIds.includes(userId);
}

// /start
async function handleStart(bot, msg) {
  const userId = msg.from.id;

  // Userni DB ga saqlash
  await db('users')
    .insert({
      telegram_id: userId,
      username: msg.from.username || null,
      first_name: msg.from.first_name || null,
    })
    .onConflict('telegram_id')
    .merge(['username', 'first_name', 'updated_at']);

  const price = process.env.SUBSCRIPTION_PRICE_MONTHLY || 50000;

  const text = `
🎬 <b>Kino Bot SaaS Platformasiga xush kelibsiz!</b>

Bu platforma orqali o'z Telegram kino botingizni yaratishingiz mumkin.

💡 <b>Imkoniyatlar:</b>
• Telegram botingizni ulang
• Majburiy obuna kanallarini sozlang
• Kino manba kanalingizni biriktiring
• Foydalanuvchilar kod orqali kino oladi

💳 <b>Narx:</b> ${price.toLocaleString()} so'm / oy

🤖 Botlaringizni boshqarish uchun tugmalardan foydalaning.
`;

  return bot.sendMessage(userId, text, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '🤖 Botlarim', callback_data: 'my_bots' },
          { text: '➕ Yangi bot yaratish', callback_data: 'create_bot' },
        ],
        [{ text: '💰 Tariflar', callback_data: 'pricing' }],
      ],
    },
  });
}

// Botlar ro'yxati
async function handleMyBots(bot, userId, chatId, messageId = null) {
  const user = await db('users').where({ telegram_id: userId }).first();
  if (!user) return;

  const bots = await db('bots').where({ owner_id: user.id });

  if (bots.length === 0) {
    const text = '❌ Sizda hali bot yo\'q.\n\n➕ "Yangi bot yaratish" tugmasini bosing.';
    const opts = {
      reply_markup: {
        inline_keyboard: [
          [{ text: '➕ Yangi bot yaratish', callback_data: 'create_bot' }],
          [{ text: '🔙 Orqaga', callback_data: 'back_main' }],
        ],
      },
    };
    return messageId
      ? bot.editMessageText(text, { chat_id: chatId, message_id: messageId, ...opts })
      : bot.sendMessage(chatId, text, opts);
  }

  const buttons = bots.map((b) => [
    {
      text: `${b.status === 'active' ? '🟢' : '🔴'} @${b.bot_username || 'bot_' + b.id}`,
      callback_data: `bot_detail:${b.id}`,
    },
  ]);
  buttons.push([{ text: '➕ Yangi bot', callback_data: 'create_bot' }]);
  buttons.push([{ text: '🔙 Orqaga', callback_data: 'back_main' }]);

  const text = `🤖 <b>Sizning botlaringiz (${bots.length} ta):</b>`;
  const opts = { parse_mode: 'HTML', reply_markup: { inline_keyboard: buttons } };

  return messageId
    ? bot.editMessageText(text, { chat_id: chatId, message_id: messageId, ...opts })
    : bot.sendMessage(chatId, text, opts);
}

// Bot detail
async function handleBotDetail(bot, userId, chatId, messageId, botId) {
  const user = await db('users').where({ telegram_id: userId }).first();
  const botRecord = await db('bots').where({ id: botId, owner_id: user.id }).first();

  if (!botRecord) return bot.answerCallbackQuery({ text: 'Bot topilmadi' });

  const channels = await db('channels').where({ bot_id: botId });
  const mandatoryCount = channels.filter((c) => c.type === 'mandatory').length;
  const groupCount = channels.filter((c) => c.type === 'group').length;

  const subEnd = botRecord.subscription_end
    ? new Date(botRecord.subscription_end).toLocaleDateString('uz-UZ')
    : 'Faol emas';

  const text = `
🤖 <b>Bot: @${botRecord.bot_username || 'Noma\'lum'}</b>

📊 Status: ${botRecord.status === 'active' ? '🟢 Aktiv' : '🔴 Inaktiv'}
📅 Obuna tugashi: ${subEnd}
📢 Majburiy kanallar: ${mandatoryCount} ta
👥 Guruhlar: ${groupCount} ta
🎬 Manba kanal: ${botRecord.source_channel_id || '❌ Sozlanmagan'}
`;

  const buttons = [
    [
      { text: '📢 Kanallar', callback_data: `bot_channels:${botId}` },
      { text: '🎬 Manba kanal', callback_data: `bot_source:${botId}` },
    ],
    [{ text: '💳 Obuna to\'lash', callback_data: `pay_bot:${botId}` }],
    [
      { text: botRecord.status === 'active' ? '🔴 To\'xtatish' : '🟢 Ishga tushirish', callback_data: `toggle_bot:${botId}` },
      { text: '🗑 O\'chirish', callback_data: `delete_bot:${botId}` },
    ],
    [{ text: '🔙 Orqaga', callback_data: 'my_bots' }],
  ];

  return bot.editMessageText(text, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: buttons },
  });
}

// Bot yaratish bosqich 1 - token so'rash
async function startBotCreation(bot, userId, chatId, messageId) {
  userStates.set(userId, { step: 'waiting_token' });

  const text = `➕ <b>Yangi bot yaratish</b>

1️⃣ @BotFather dan yangi bot yarating
2️⃣ Bot tokenini yuboring

📝 <b>Token formatı:</b>
<code>1234567890:ABCdefGHIjklMNOpqrSTUvwxyz</code>

❌ Bekor qilish uchun /cancel yuboring.`;

  return bot.editMessageText(text, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
  }).catch(() => bot.sendMessage(chatId, text, { parse_mode: 'HTML' }));
}

// Token qabul qilish
async function handleTokenInput(bot, msg, app) {
  const userId = msg.from.id;
  const token = msg.text.trim();

  if (token === '/cancel') {
    userStates.delete(userId);
    return bot.sendMessage(msg.chat.id, '❌ Bekor qilindi.', {
      reply_markup: { inline_keyboard: [[{ text: '🏠 Asosiy menyu', callback_data: 'back_main' }]] },
    });
  }

  // Token validatsiya
  if (!/^\d+:[A-Za-z0-9_-]{35,}$/.test(token)) {
    return bot.sendMessage(msg.chat.id, '❌ Token noto\'g\'ri formatda. Qaytadan yuboring:');
  }

  // Token Telegram da tekshirish
  try {
    const TelegramBot = require('node-telegram-bot-api');
    const testBot = new TelegramBot(token);
    const botInfo = await testBot.getMe();
    await testBot.deleteWebHook(); // cleanup

    const user = await db('users').where({ telegram_id: userId }).first();

    // Token allaqachon mavjudmi?
    const existing = await db('bots').whereRaw(
      'token_encrypted IS NOT NULL'
    ).then(async (bots) => {
      for (const b of bots) {
        try {
          if (decrypt(b.token_encrypted) === token) return b;
        } catch { /* skip */ }
      }
      return null;
    });

    if (existing) {
      return bot.sendMessage(msg.chat.id, '❌ Bu token allaqachon ro\'yxatdan o\'tgan!');
    }

    // DB ga saqlash
    const [newBot] = await db('bots')
      .insert({
        owner_id: user.id,
        token_encrypted: encrypt(token),
        bot_username: botInfo.username,
        bot_name: botInfo.first_name,
        status: 'inactive',
      })
      .returning('*');

    userStates.delete(userId);

    await bot.sendMessage(
      msg.chat.id,
      `✅ <b>Bot muvaffaqiyatli qo'shildi!</b>\n\n🤖 @${botInfo.username}\n\n⚠️ Botni faollashtirish uchun obuna to'lang.`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '💳 Obuna to\'lash', callback_data: `pay_bot:${newBot.id}` }],
            [{ text: '🤖 Botlarim', callback_data: 'my_bots' }],
          ],
        },
      }
    );
  } catch (err) {
    logger.error('Token validation error:', err.message);
    return bot.sendMessage(msg.chat.id, '❌ Token yaroqsiz yoki bot topilmadi. Qaytadan yuboring:');
  }
}

// To'lov tanlash menyusi
async function handlePayBot(bot, userId, chatId, messageId, botId) {
  const price = process.env.SUBSCRIPTION_PRICE_MONTHLY || 50000;

  const text = `💳 <b>Obuna to'lash</b>

💰 Narx: <b>${parseInt(price).toLocaleString()} so'm / oy</b>
🤖 Bot ID: <code>#${botId}</code>

To'lov usulini tanlang:`;

  return bot.editMessageText(text, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        // Click va Payme — hozircha yopiq
        [
          { text: '🔒 Click (tez kunda)', callback_data: 'pay_disabled' },
          { text: '🔒 Payme (tez kunda)', callback_data: 'pay_disabled' },
        ],
        // Admin orqali — faol
        [{ text: '✅ Admin orqali to\'lash', callback_data: `pay_admin:${botId}` }],
        [{ text: '🔙 Orqaga', callback_data: `bot_detail:${botId}` }],
      ],
    },
  });
}

// Admin orqali to'lash — foydalanuvchiga @jaconjs ga yozish uchun deep link
async function handleAdminPayment(bot, userId, chatId, messageId, botId) {
  const price = process.env.SUBSCRIPTION_PRICE_MONTHLY || 50000;
  const adminUsername = process.env.PAYMENT_ADMIN_USERNAME || 'jaconjs';

  // Botning username ini olish
  const botRecord = await db('bots').where({ id: botId }).first();
  const botUsername = botRecord?.bot_username || `id_${botId}`;

  // Foydalanuvchi @jaconjs ga yuboradigan tayyor xabar matni
  const msgText = encodeURIComponent(
    `Salom! @${botUsername} botimdagi obunani to'lamoqchiman.\n\nBot ID: #${botId}\nNarx: ${parseInt(price).toLocaleString()} so'm`
  );

  // Telegram deep link — bosing = @jaconjs ga xabar yoziladi
  const adminChatUrl = `https://t.me/${adminUsername}?text=${msgText}`;

  const text = `👨‍💼 <b>Admin orqali to'lash</b>

💰 Narx: <b>${parseInt(price).toLocaleString()} so'm / oy</b>
🤖 Bot: <code>@${botUsername}</code>

📋 <b>Jarayon:</b>
1️⃣ Quyidagi tugmani bosing
2️⃣ Adminga P2P o'tkazing
3️⃣ Admin botingizni faollashtiradi

⚡ Odatda <b>5-15 daqiqa</b> ichida faollashadi.`;

  return bot.editMessageText(text, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [{ text: '💬 Adminga yozish', url: adminChatUrl }],
        [{ text: '🔙 Orqaga', callback_data: `pay_bot:${botId}` }],
      ],
    },
  });
}

// Toggle bot
async function handleToggleBot(bot, userId, chatId, messageId, botId, app) {
  const user = await db('users').where({ telegram_id: userId }).first();
  const botRecord = await db('bots').where({ id: botId, owner_id: user.id }).first();

  if (!botRecord) return;

  if (botRecord.status === 'active') {
    await db('bots').where({ id: botId }).update({ status: 'inactive' });
    await stopChildBot(botId);
    await bot.answerCallbackQuery({ text: '🔴 Bot to\'xtatildi' });
  } else {
    // Subscription tekshirish
    if (!botRecord.subscription_end || new Date(botRecord.subscription_end) < new Date()) {
      return bot.editMessageText('❌ Obuna muddati tugagan. Avval to\'lang.', {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: {
          inline_keyboard: [[{ text: '💳 To\'lash', callback_data: `pay_bot:${botId}` }]],
        },
      });
    }
    await db('bots').where({ id: botId }).update({ status: 'active' });
    await startChildBot({ ...botRecord, status: 'active' }, app);
    await bot.answerCallbackQuery({ text: '🟢 Bot ishga tushirildi' });
  }

  return handleBotDetail(bot, userId, chatId, messageId, botId);
}

// Kanallar boshqaruvi
async function handleBotChannels(bot, userId, chatId, messageId, botId) {
  const channels = await db('channels').where({ bot_id: botId, type: 'mandatory' });

  let text = `📢 <b>Majburiy kanallar (${channels.length} ta):</b>\n\n`;
  channels.forEach((ch, i) => {
    text += `${i + 1}. ${ch.channel_name || ch.channel_id}\n`;
  });
  if (channels.length === 0) text += 'Hali kanal qo\'shilmagan\n';

  const buttons = channels.map((ch) => [
    { text: `🗑 ${ch.channel_name || ch.channel_id}`, callback_data: `del_channel:${ch.id}:${botId}` },
  ]);
  buttons.push([{ text: '➕ Kanal qo\'shish', callback_data: `add_channel:${botId}` }]);
  buttons.push([{ text: '🔙 Orqaga', callback_data: `bot_detail:${botId}` }]);

  return bot.editMessageText(text, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: buttons },
  });
}

// Manba kanal sozlash
async function handleBotSource(bot, userId, chatId, messageId, botId) {
  userStates.set(userId, { step: 'waiting_source', botId });

  return bot.editMessageText(
    `🎬 <b>Manba kanal ID kiriting:</b>\n\nMisol: <code>-1001234567890</code>\n\n❌ Bekor qilish: /cancel`,
    {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
    }
  );
}

// Asosiy message handler
async function handleMainBotMessage(bot, msg, app) {
  const userId = msg.from.id;
  const text = msg.text;

  if (!text) return;

  const state = userStates.get(userId);

  if (state?.step === 'waiting_token') {
    return handleTokenInput(bot, msg, app);
  }

  if (state?.step === 'waiting_source') {
    const channelId = text.trim();
    await db('bots').where({ id: state.botId }).update({ source_channel_id: channelId });
    userStates.delete(userId);
    return bot.sendMessage(userId, `✅ Manba kanal saqlandi: <code>${channelId}</code>`, { parse_mode: 'HTML' });
  }

  if (state?.step === 'waiting_channel') {
    const channelId = text.trim();
    await db('channels').insert({
      bot_id: state.botId,
      channel_id: channelId,
      channel_name: channelId,
      type: 'mandatory',
    });
    userStates.delete(userId);
    return bot.sendMessage(userId, `✅ Kanal qo'shildi: <code>${channelId}</code>`, { parse_mode: 'HTML' });
  }

  if (text === '/start') return handleStart(bot, msg);
  if (text === '/admin' && isAdmin(userId)) return handleAdminPanel(bot, msg);
}

// Callback handler
async function handleMainBotCallback(bot, query, app) {
  const userId = query.from.id;
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;
  const data = query.data;

  await bot.answerCallbackQuery(query.id).catch(() => {});

  if (data === 'my_bots') return handleMyBots(bot, userId, chatId, messageId);
  if (data === 'create_bot') return startBotCreation(bot, userId, chatId, messageId);
  if (data === 'back_main') return handleStart(bot, { from: { id: userId }, chat: { id: chatId } });

  if (data === 'pricing') {
    const price = process.env.SUBSCRIPTION_PRICE_MONTHLY || 50000;
    return bot.editMessageText(
      `💰 <b>Tariflar:</b>\n\n📅 1 oy: <b>${parseInt(price).toLocaleString()} so'm</b>\n\n✅ To'lovdan so'ng bot darhol faollashadi.`,
      { chat_id: chatId, message_id: messageId, parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🔙 Orqaga', callback_data: 'back_main' }]] } }
    );
  }

  if (data.startsWith('bot_detail:')) {
    const botId = parseInt(data.split(':')[1]);
    return handleBotDetail(bot, userId, chatId, messageId, botId);
  }

  if (data.startsWith('pay_bot:')) {
    const botId = parseInt(data.split(':')[1]);
    return handlePayBot(bot, userId, chatId, messageId, botId);
  }

  // Click / Payme hozircha yopiq
  if (data === 'pay_disabled') {
    return bot.answerCallbackQuery(query.id, {
      text: '🔒 Bu to\'lov usuli hozircha mavjud emas. Admin orqali to\'lang.',
      show_alert: true,
    });
  }

  if (data.startsWith('pay_admin:')) {
    const botId = parseInt(data.split(':')[1]);
    return handleAdminPayment(bot, userId, chatId, messageId, botId);
  }

  if (data.startsWith('toggle_bot:')) {
    const botId = parseInt(data.split(':')[1]);
    return handleToggleBot(bot, userId, chatId, messageId, botId, app);
  }

  if (data.startsWith('bot_channels:')) {
    const botId = parseInt(data.split(':')[1]);
    return handleBotChannels(bot, userId, chatId, messageId, botId);
  }

  if (data.startsWith('bot_source:')) {
    const botId = parseInt(data.split(':')[1]);
    return handleBotSource(bot, userId, chatId, messageId, botId);
  }

  if (data.startsWith('add_channel:')) {
    const botId = parseInt(data.split(':')[1]);
    userStates.set(userId, { step: 'waiting_channel', botId });
    return bot.editMessageText('📢 Kanal ID kiriting:\n\nMisol: <code>@mychannel</code> yoki <code>-1001234567890</code>', {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
    });
  }

  if (data.startsWith('del_channel:')) {
    const [, channelId, botId] = data.split(':');
    await db('channels').where({ id: channelId }).delete();
    return handleBotChannels(bot, userId, chatId, messageId, parseInt(botId));
  }

  if (data.startsWith('admin_')) {
    return handleAdminCallback(bot, query, data);
  }
}

// ─── ADMIN: /activate <bot_id> [kunlar] ─────────────────────
async function handleActivateCommand(bot, msg, app) {
  const userId = msg.from.id;
  if (!isAdmin(userId)) return;

  const parts = msg.text.trim().split(/\s+/);
  const botId = parseInt(parts[1]);
  const days = parseInt(parts[2]) || parseInt(process.env.SUBSCRIPTION_DURATION_DAYS) || 30;

  if (!botId || isNaN(botId)) {
    return bot.sendMessage(userId,
      '❌ Noto\'g\'ri format.\n\nTo\'g\'ri: <code>/activate &lt;bot_id&gt; [kunlar]</code>\n\nMisol: <code>/activate 42</code> yoki <code>/activate 42 60</code>',
      { parse_mode: 'HTML' }
    );
  }

  const botRecord = await db('bots').where({ id: botId }).first();
  if (!botRecord) {
    return bot.sendMessage(userId, `❌ Bot #${botId} topilmadi.`);
  }

  const now = new Date();
  const currentEnd = botRecord.subscription_end ? new Date(botRecord.subscription_end) : now;
  const base = currentEnd > now ? currentEnd : now;
  const newEnd = new Date(base);
  newEnd.setDate(newEnd.getDate() + days);

  await db('bots').where({ id: botId }).update({
    status: 'active',
    subscription_end: newEnd,
  });

  const { startChildBot } = require('./botManager');
  await startChildBot({ ...botRecord, status: 'active', subscription_end: newEnd }, app);

  const owner = await db('users')
    .join('bots', 'users.id', 'bots.owner_id')
    .where('bots.id', botId)
    .select('users.telegram_id')
    .first();

  if (owner) {
    // Qo'llanma havolasi (public)
    const baseUrl = process.env.BASE_URL || '';
    const guideUrl = `${baseUrl}/guide`;

    await bot.sendMessage(
      owner.telegram_id,
      `✅ <b>Botingiz faollashtirildi!</b>\n\n🤖 @${botRecord.bot_username || 'bot_' + botId}\n📅 Obuna tugashi: <b>${newEnd.toLocaleDateString('uz-UZ')}</b>\n\nEndi botingiz ishlaydi! 🎬\n\n📖 Botdan to'g'ri foydalanish uchun qo'llanmani o'qing:`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '📖 Foydalanuvchi qo\'llanmasi', url: guideUrl }],
          ],
        },
      }
    );
  }

  return bot.sendMessage(
    userId,
    `✅ <b>Bajarildi!</b>\n\n🤖 @${botRecord.bot_username || 'bot_' + botId}\n📅 Tugash: <b>${newEnd.toLocaleDateString('uz-UZ')}</b> (+${days} kun)\n👤 Egasiga xabar + qo\'llanma havolasi yuborildi.`,
    { parse_mode: 'HTML' }
  );
}

// Admin panel
async function handleAdminPanel(bot, msg) {
  const userId = msg.from.id;
  if (!isAdmin(userId)) return;

  const [userCount] = await db('users').count('id as count');
  const [botCount] = await db('bots').count('id as count');
  const [activeCount] = await db('bots').where({ status: 'active' }).count('id as count');
  const [pendingCount] = await db('bots').where({ status: 'inactive' }).count('id as count');

  const text = `👨‍💼 <b>Admin Panel</b>

👥 Foydalanuvchilar: <b>${userCount.count}</b>
🤖 Jami botlar: <b>${botCount.count}</b>
🟢 Aktiv: <b>${activeCount.count}</b>
⏳ Kutayotgan: <b>${pendingCount.count}</b>

💡 Faollashtirish: <code>/activate &lt;bot_id&gt;</code>`;

  return bot.sendMessage(userId, text, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '📊 Statistika', callback_data: 'admin_stats' },
          { text: '🤖 Botlar', callback_data: 'admin_bots' },
        ],
        [
          { text: '⏳ Kutayotganlar', callback_data: 'admin_pending' },
          { text: '👥 Foydalanuvchilar', callback_data: 'admin_users' },
        ],
      ],
    },
  });
}

async function handleAdminCallback(bot, query, data, app) {
  const userId = query.from.id;
  if (!isAdmin(userId)) return;

  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;

  if (data === 'admin_stats') {
    const [users] = await db('users').count('id as c');
    const [bots] = await db('bots').count('id as c');
    const [active] = await db('bots').where({ status: 'active' }).count('id as c');
    return bot.editMessageText(
      `📊 <b>Statistika:</b>\n\n👥 Users: ${users.c}\n🤖 Botlar: ${bots.c}\n🟢 Aktiv: ${active.c}`,
      { chat_id: chatId, message_id: messageId, parse_mode: 'HTML',
        reply_markup: { inline_keyboard: [[{ text: '🔙 Orqaga', callback_data: 'admin_back' }]] } }
    );
  }

  if (data === 'admin_pending') {
    const pending = await db('bots')
      .join('users', 'bots.owner_id', 'users.id')
      .where({ 'bots.status': 'inactive' })
      .select('bots.id', 'bots.bot_username', 'users.telegram_id', 'users.username', 'bots.created_at')
      .orderBy('bots.created_at', 'desc').limit(20);

    let text = `⏳ <b>Kutayotgan botlar (${pending.length} ta):</b>\n\n`;
    pending.forEach((b) => {
      const uname = b.username ? `@${b.username}` : `ID:${b.telegram_id}`;
      text += `🤖 @${b.bot_username || 'nomsiz'} — ${uname}\n<code>/activate ${b.id}</code>\n\n`;
    });
    if (pending.length === 0) text += 'Hamma bot aktiv ✅';

    return bot.editMessageText(text, {
      chat_id: chatId, message_id: messageId, parse_mode: 'HTML',
      reply_markup: { inline_keyboard: [[{ text: '🔙 Orqaga', callback_data: 'admin_back' }]] }
    });
  }

  if (data === 'admin_bots') {
    const bots = await db('bots')
      .join('users', 'bots.owner_id', 'users.id')
      .select('bots.id', 'bots.bot_username', 'bots.status', 'bots.subscription_end', 'users.username')
      .orderBy('bots.created_at', 'desc').limit(15);

    let text = '🤖 <b>Botlar ro\'yxati:</b>\n\n';
    bots.forEach((b) => {
      const icon = b.status === 'active' ? '🟢' : '🔴';
      const end = b.subscription_end ? new Date(b.subscription_end).toLocaleDateString('uz-UZ') : 'Yo\'q';
      text += `${icon} @${b.bot_username || 'id_' + b.id} | ${end} | @${b.username || b.id}\n`;
    });

    return bot.editMessageText(text, {
      chat_id: chatId, message_id: messageId, parse_mode: 'HTML',
      reply_markup: { inline_keyboard: [[{ text: '🔙 Orqaga', callback_data: 'admin_back' }]] }
    });
  }

  if (data === 'admin_users') {
    const users = await db('users')
      .select('users.*', db.raw('COUNT(bots.id) as bot_count'))
      .leftJoin('bots', 'users.id', 'bots.owner_id')
      .groupBy('users.id').orderBy('users.created_at', 'desc').limit(15);

    let text = '👥 <b>Foydalanuvchilar:</b>\n\n';
    users.forEach((u) => {
      text += `👤 ${u.username ? '@' + u.username : u.first_name || 'Nomsiz'} — ${u.bot_count} ta bot\n`;
    });

    return bot.editMessageText(text, {
      chat_id: chatId, message_id: messageId, parse_mode: 'HTML',
      reply_markup: { inline_keyboard: [[{ text: '🔙 Orqaga', callback_data: 'admin_back' }]] }
    });
  }

  if (data === 'admin_back') {
    return handleAdminPanel(bot, { from: { id: userId }, chat: { id: chatId } });
  }
}

module.exports = {
  handleMainBotMessage,
  handleMainBotCallback,
  handleAdminPanel,
  handleActivateCommand,
  isAdmin,
};