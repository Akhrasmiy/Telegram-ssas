const TelegramBot = require('node-telegram-bot-api');
const db = require('../db');
const { decrypt } = require('../utils/encryption');
const logger = require('../utils/logger');
const { handleChildBotMessage } = require('./childBotHandler');

// Active bot instances: { botId: TelegramBot }
const activeBots = new Map();

async function loadAllBots(app) {
  try {
    const bots = await db('bots').where({ status: 'active' });
    logger.info(`Loading ${bots.length} active bots...`);

    for (const bot of bots) {
      await startChildBot(bot, app);
    }
  } catch (err) {
    logger.error('Error loading bots:', err);
  }
}

async function startChildBot(botRecord, app) {
  try {
    if (activeBots.has(botRecord.id)) {
      logger.info(`Bot #${botRecord.id} already running`);
      return;
    }

    const token = decrypt(botRecord.token_encrypted);
    const bot = new TelegramBot(token);

    // Set webhook
    const webhookUrl = `${process.env.BASE_URL}/webhook/child/${botRecord.id}`;
    await bot.setWebHook(webhookUrl, {
      secret_token: process.env.WEBHOOK_SECRET,
    });

    // Register webhook route dynamically
    app.post(`/webhook/child/${botRecord.id}`, (req, res) => {
      bot.processUpdate(req.body);
      res.sendStatus(200);
    });

    // Attach handlers
    bot.on('message', (msg) => handleChildBotMessage(bot, msg, botRecord));
    bot.on('callback_query', (query) => handleChildBotCallback(bot, query, botRecord));

    activeBots.set(botRecord.id, bot);
    logger.info(`✅ Child bot #${botRecord.id} (@${botRecord.bot_username}) started`);
  } catch (err) {
    logger.error(`❌ Failed to start bot #${botRecord.id}:`, err.message);
  }
}

async function stopChildBot(botId) {
  const bot = activeBots.get(botId);
  if (bot) {
    await bot.deleteWebHook();
    activeBots.delete(botId);
    logger.info(`🔴 Child bot #${botId} stopped`);
  }
}

async function restartChildBot(botRecord, app) {
  await stopChildBot(botRecord.id);
  await startChildBot(botRecord, app);
}

function getBotInstance(botId) {
  return activeBots.get(botId);
}

// Handle callback queries for child bots
async function handleChildBotCallback(bot, query, botRecord) {
  const { handleChildBotCallback: handler } = require('./childBotHandler');
  await handler(bot, query, botRecord);
}

module.exports = {
  loadAllBots,
  startChildBot,
  stopChildBot,
  restartChildBot,
  getBotInstance,
  activeBots,
};
