const db = require('../db');
const logger = require('../utils/logger');
const { startChildBot } = require('../bots/botManager');

async function activateSubscription(botId, transactionId) {
  const bot = await db('bots').where({ id: botId }).first();
  if (!bot) return;

  const days = parseInt(process.env.SUBSCRIPTION_DURATION_DAYS) || 30;

  // Joriy obunani uzaytirish
  const now = new Date();
  const currentEnd = bot.subscription_end ? new Date(bot.subscription_end) : now;
  const base = currentEnd > now ? currentEnd : now;

  const newEnd = new Date(base);
  newEnd.setDate(newEnd.getDate() + days);

  await db('bots').where({ id: botId }).update({
    status: 'active',
    subscription_end: newEnd,
  });

  logger.info(`✅ Subscription activated: Bot #${botId}, ends: ${newEnd.toISOString()}`);

  // Bot egasiga xabar yuborish
  try {
    const owner = await db('users')
      .join('bots', 'users.id', 'bots.owner_id')
      .where('bots.id', botId)
      .select('users.telegram_id')
      .first();

    if (owner) {
      const { getBotInstance } = require('../bots/botManager');
      const mainBotToken = process.env.MAIN_BOT_TOKEN;
      const TelegramBot = require('node-telegram-bot-api');
      const notifyBot = new TelegramBot(mainBotToken);

      await notifyBot.sendMessage(
        owner.telegram_id,
        `✅ <b>To'lov qabul qilindi!</b>\n\n🤖 Bot #${botId} faollashtirildi\n📅 Obuna tugashi: ${newEnd.toLocaleDateString('uz-UZ')}`
          .replace('@', '\\@'),
        { parse_mode: 'HTML' }
      );
    }
  } catch (err) {
    logger.error('Notification error:', err.message);
  }
}

async function deactivateExpiredBots() {
  const now = new Date();

  const expired = await db('bots')
    .where({ status: 'active' })
    .where('subscription_end', '<', now);

  for (const bot of expired) {
    await db('bots').where({ id: bot.id }).update({ status: 'inactive' });
    const { stopChildBot } = require('../bots/botManager');
    await stopChildBot(bot.id);
    logger.info(`🔴 Bot #${bot.id} deactivated (subscription expired)`);
  }

  return expired.length;
}

async function notifyExpiringBots() {
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const dayAfter = new Date();
  dayAfter.setDate(dayAfter.getDate() + 2);

  const expiring = await db('bots')
    .where({ status: 'active' })
    .whereBetween('subscription_end', [tomorrow, dayAfter]);

  const TelegramBot = require('node-telegram-bot-api');
  const notifyBot = new TelegramBot(process.env.MAIN_BOT_TOKEN);

  for (const bot of expiring) {
    try {
      const owner = await db('users')
        .join('bots', 'users.id', 'bots.owner_id')
        .where('bots.id', bot.id)
        .select('users.telegram_id')
        .first();

      if (owner) {
        await notifyBot.sendMessage(
          owner.telegram_id,
          `⚠️ <b>Diqqat!</b>\n\n🤖 @${bot.bot_username || 'bot_' + bot.id} botingiz obunasi ertaga tugaydi!\n\n💳 To'lov qilish uchun /start yuboring.`,
          { parse_mode: 'HTML' }
        );
        logger.info(`📨 Expiry notification sent for bot #${bot.id}`);
      }
    } catch (err) {
      logger.error(`Notification error for bot #${bot.id}:`, err.message);
    }
  }
}

module.exports = { activateSubscription, deactivateExpiredBots, notifyExpiringBots };
