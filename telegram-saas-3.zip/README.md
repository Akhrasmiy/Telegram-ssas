# 🎬 Telegram Kino Bot SaaS Platformasi

Multi-bot SaaS platforma — foydalanuvchilar o'z Telegram kino botlarini yaratadi va boshqaradi.

---

## 📦 O'rnatish

### 1. Talablar
- Node.js 18+
- PostgreSQL 14+
- Redis 6+
- PM2 (`npm install -g pm2`)

### 2. Loyihani yuklab olish
```bash
git clone <repo_url>
cd telegram-saas
npm install
```

### 3. `.env` faylini sozlash
```bash
cp .env.example .env
nano .env
```

`.env` ichida to'ldiring:
```
PORT=3000
BASE_URL=https://yourdomain.com

DB_HOST=localhost
DB_PORT=5432
DB_NAME=telegram_saas
DB_USER=postgres
DB_PASSWORD=yourpassword

REDIS_URL=redis://localhost:6379

MAIN_BOT_TOKEN=your_main_bot_token
ADMIN_IDS=123456789,987654321
ADMIN_API_KEY=your_secret_admin_api_key

CLICK_SERVICE_ID=...
CLICK_SECRET_KEY=...
CLICK_MERCHANT_ID=...

PAYME_MERCHANT_ID=...
PAYME_SECRET_KEY=...

ENCRYPTION_KEY=32_ta_belgidan_iborat_kalit!!!!!
SUBSCRIPTION_PRICE_MONTHLY=50000
SUBSCRIPTION_DURATION_DAYS=30
WEBHOOK_SECRET=your_webhook_secret
```

### 4. Database yaratish
```bash
psql -U postgres -c "CREATE DATABASE telegram_saas;"
```

### 5. Migratsiyalarni ishga tushirish
```bash
npm run migrate
```

### 6. Ishga tushirish

**Development:**
```bash
npm run dev
```

**Production (PM2):**
```bash
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

---

## 🏗 Loyiha tuzilmasi

```
src/
├── index.js              ← Asosiy server
├── db/index.js           ← PostgreSQL ulanish
├── config/redis.js       ← Redis ulanish
├── migrations/           ← DB migratsiyalar
│   ├── ..._users.js
│   ├── ..._bots.js
│   ├── ..._channels.js
│   ├── ..._transactions.js
│   └── ..._movies.js
├── bots/
│   ├── botManager.js     ← Multi-bot boshqaruvi
│   ├── mainBotHandler.js ← Ota-bot logikasi
│   └── childBotHandler.js← O'g'il bot logikasi
├── payments/
│   ├── click.js          ← Click integratsiya
│   └── payme.js          ← Payme integratsiya
├── utils/
│   ├── logger.js         ← Winston logger
│   ├── encryption.js     ← Token shifrlash
│   └── subscription.js   ← Obuna logikasi
├── admin/routes.js       ← REST Admin API
├── cron/index.js         ← Cron joblar
└── middlewares/
    └── webhookAuth.js    ← Webhook xavfsizlik
```

---

## 🔌 API Endpointlar

| Method | URL | Tavsif |
|--------|-----|--------|
| GET | `/health` | Server holati |
| POST | `/webhook/main` | Ota-bot webhook |
| POST | `/webhook/child/:id` | O'g'il bot webhook |
| POST | `/api/click/prepare` | Click prepare |
| POST | `/api/click/complete` | Click complete |
| POST | `/api/payme` | Payme JSON-RPC |
| GET | `/admin/stats` | Statistika |
| GET | `/admin/bots` | Botlar ro'yxati |
| GET | `/admin/transactions` | To'lovlar |
| GET | `/admin/users` | Foydalanuvchilar |

---

## 🎬 Kino indexlash

Kino manba kanalga post yuborganda, caption/text ichida kod bo'lishi kerak:

```
#KN001
Avengers: Endgame
```

Bot avtomatik indexlab oladi va foydalanuvchilar `KN001` kodini yuborganida kino keladi.

---

## 🔒 Xavfsizlik

- Bot tokenlar AES-256-CBC bilan shifrlangan
- Webhook secret token bilan himoyalangan
- Payme Basic Auth bilan himoyalangan
- Click MD5 signature tekshiriladi

---

## 📊 Monitoring

```bash
pm2 logs telegram-saas
pm2 monit
```
